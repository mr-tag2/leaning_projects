﻿using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using Accounting;


namespace AccountingAPP
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Transaction> list = new List<Transaction>();

            while (true)
            {

                Console.WriteLine("Well Come !\n-------------------------------------------\n");

                Console.WriteLine("1 - Add Transaction ");
                Console.WriteLine("2 - Show All ");
                Console.WriteLine("3 - Exit ");


                Console.Write("Enter Your Choose : ");

                try
                {
                    int Choise = Convert.ToInt16(Console.ReadLine());

                    if (Choise == 3) break;

                    if (Choise == 1)
                    {
                        Transaction arrayValues = new Transaction();

                        Console.WriteLine("\n\nEnter Your Transaction Values.\n\n");

                        Console.Write("Enter Value : ");
                        arrayValues.Value = Convert.ToDecimal(Console.ReadLine());

                        Console.Write("Enter Title : ");
                        arrayValues.Title = Console.ReadLine();

                        Console.Write("Enter Description : ");
                        arrayValues.Description = Console.ReadLine();

                        list.Add(arrayValues);
                    }
                   
                    Console.Clear();

                }
                catch
                {
                    Console.WriteLine("\n-------------------------------------------\nError\n-------------------------------------------\n");
                }
            }
        }
    }
}
